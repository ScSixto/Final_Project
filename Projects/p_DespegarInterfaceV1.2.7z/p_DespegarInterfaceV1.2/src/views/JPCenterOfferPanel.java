package views;

import javax.swing.*;
import java.awt.*;

public class JPCenterOfferPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	
	public JPCenterOfferPanel(){
        this.setPreferredSize(new Dimension(WIDTH,378));
        this.setBackground(ConstantsGUI.COLOR_DESPEGAR_ULTRA_LIGHT_GRAY);
        this.setOpaque(true);
    }
}
