package views;

import javax.swing.*;
import java.awt.*;

public class JPMainPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	
    public JPMainPanel(){
        this.addScrolling();
        this.setBackground(ConstantsGUI.COLOR_WHITE);
        this.setLayout(new BorderLayout());
        this.initComponents();
    }

    public void initComponents(){
        this.addNorthPanel();
        this.addCenterPanel();
        //this.addSouthPanel();
    }

    public void addNorthPanel(){
        this.add(new JPNorthPanel(),BorderLayout.NORTH);
    }

    public void addCenterPanel(){
        this.add(new JPCenterPanel(),BorderLayout.CENTER);
    }

    public void addSouthPanel(){
        JPanel panel = new JPanel();
        panel.setPreferredSize(new Dimension(WIDTH,600));
        this.add(panel,BorderLayout.SOUTH);
    }

    public void addScrolling(){
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBounds(50, 30, 300, 50);
        this.add(new Scrollbar(Scrollbar.VERTICAL));
    }
}