package views;

import javax.swing.*;
import java.awt.*;

public class JMBNorthButtonBar extends JMenuBar{

	private static final long serialVersionUID = 1L;
	
    public static final String HOUSING_ICON_PATH = "resources/img/Alojamiento.png";
    public static final String HOUSING_TEXT = "Alojamientos";
    public static final String TRAVELS_ICON_PATH = "resources/img/Vuelos.png";
    public static final String TRAVELS_TEXT = "Vuelos";
    public static final String PACKAGE_ICON_PATH = "resources/img/Paquetes.png";
    public static final String PACKAGE_TEXT = "Paquetes";
    public static final String UNBEATABLE_ICON_PATH = "resources/img/Imbatibles.png";
    public static final String UNBEATABLE_TEXT = "Imbatibles";
    public static final String ESCAPE_ICON_PATH = "resources/img/Escapadas.png";
    public static final String ESCAPE_TEXT = "Escapadas";
    public static final String ACTIVITIES_ICON_PATH = "resources/img/Actividades.png";
    public static final String ACTIVITIES_TEXT = "Actividades";
    public static final String CARS_ICON_PATH = "resources/img/Carros.png";
    public static final String CARS_TEXT = "Carros";
    public static final String DISNEY_ICON_PATH = "resources/img/Disney.png";
    public static final String DISNEY_TEXT = "Disney";
    public static final String INSURENCES_ICON_PATH = "resources/img/Seguros.png";
    public static final String INSURENCES_TEXT = "Seguros";
    public static final String TRANSFERS_ICON_PATH = "resources/img/Traslados.png";
    public static final String TRANSFERS_TEXT = "Traslados";
    public static final String CRUISERS_ICON_PATH = "resources/img/Cruceros.png";
    public static final String CRUISERS_TEXT = "Cruceros";

    public JMBNorthButtonBar(){
        this.setPreferredSize(new Dimension(1020,82));
        this.setBackground(ConstantsGUI.COLOR_WHITE);
        this.setOpaque(false);

        this.setBorderPainted(false);
        this.setBorder(BorderFactory.createEmptyBorder(20,40,0,0));

        FlowLayout layout = new FlowLayout(FlowLayout.LEFT);
        layout.setHgap(30);
        this.setLayout(layout);

        this.initComponents();
    }

    public void initComponents(){
        this.add(new JBNorthMenuBarButton(HOUSING_TEXT,HOUSING_ICON_PATH));
        this.add(new JBNorthMenuBarButton(TRAVELS_TEXT,TRAVELS_ICON_PATH));
        this.add(new JBNorthMenuBarButton(PACKAGE_TEXT,PACKAGE_ICON_PATH));
        this.add(new JBNorthMenuBarButton(UNBEATABLE_TEXT,UNBEATABLE_ICON_PATH));
        this.add(new JBNorthMenuBarButton(ESCAPE_TEXT,ESCAPE_ICON_PATH));
        this.add(new JBNorthMenuBarButton(ACTIVITIES_TEXT,ACTIVITIES_ICON_PATH));
        this.add(new JBNorthMenuBarButton(CARS_TEXT,CARS_ICON_PATH));
        this.add(new JBNorthMenuBarButton(DISNEY_TEXT,DISNEY_ICON_PATH));
        this.add(new JBNorthMenuBarButton(INSURENCES_TEXT,INSURENCES_ICON_PATH));
        this.add(new JBNorthMenuBarButton(TRANSFERS_TEXT,TRANSFERS_ICON_PATH));
        this.add(new JBNorthMenuBarButton(CRUISERS_TEXT,CRUISERS_ICON_PATH));
    }
}