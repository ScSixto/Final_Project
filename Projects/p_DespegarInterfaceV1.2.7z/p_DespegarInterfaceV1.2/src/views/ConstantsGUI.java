package views;

import java.awt.*;

public class ConstantsGUI {

    public static final Color COLOR_DESPEGAR_DARK_PURPLE = Color.decode("#4300d2");
    public static final Color COLOR_DESPEGAR_ULTRA_LIGHT_GRAY = Color.decode("#EEEEEE");
    public static final Color COLOR_DESPEGAR_LIGHT_GRAY = Color.decode("#666666");
    public static final Color COLOR_DESPEGAR_LIGHT_GRAY_2 = Color.decode("#888888");
    public static final Color COLOR_DESPEGAR_LIGHT_GRAY_3 = Color.decode("#aaaaaa");
    public static final Color COLOR_DESPEGAR_LIGHT_PURPLE = Color.decode("#ddd5f5");
    public static final Color COLOR_WHITE = Color.decode("#ffffff");
    public static final Color COLOR_DESPEGAR_DARK_GRAY = Color.decode("#444444");
    public static final Color COLOR_DESPEGAR_SCROLL_GRAY = Color.decode("#C1C1C1");
    public static final Color COLOR_IMPOSSIBLE = Color.decode("#2DFF0C");

    public static final Font FONT_GENERAL_BUTTON = new Font("Arial",Font.PLAIN,14);
    public static final Font TEXT_FIELD_FONT = new Font("Arial",Font.ITALIC,14);
    public static final Font SELECTION_SECTION_TITLE_FONT = new Font("Arial",Font.BOLD,13);
    public static final Font SECTION_TITLE_FONT = new Font("Arial",Font.BOLD,20);
}
