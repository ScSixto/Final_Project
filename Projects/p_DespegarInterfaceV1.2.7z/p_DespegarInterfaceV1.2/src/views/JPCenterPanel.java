package views;

import javax.swing.*;

public class JPCenterPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	
    public JPCenterPanel(){
        this.setBackground(ConstantsGUI.COLOR_WHITE);
        this.setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
        this.initComponents();
    }

    public void initComponents(){
        this.add(new JPCenterSelectionPanel());
        this.add(new JPCenterOfferPanel());
    }
}
