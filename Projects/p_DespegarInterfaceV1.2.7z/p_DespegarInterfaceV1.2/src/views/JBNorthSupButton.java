package views;

import javax.swing.*;
import java.awt.*;

public class JBNorthSupButton extends JButton {

	private static final long serialVersionUID = 1L;
	
	public static final Dimension DEFAULT_BUTTON_DIMENSION = new Dimension(148,32);

    public JBNorthSupButton(String text, String iconPath, Dimension size,Font font,Color foreground){
        super(text);
        this.setVerticalTextPosition(SwingConstants.CENTER);
        this.setHorizontalTextPosition(SwingConstants.RIGHT);
        this.setFont(font);
        this.setForeground(foreground);

        this.setBackground(ConstantsGUI.COLOR_WHITE);
        this.setOpaque(false);
        this.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
        this.setBorderPainted(false);

        this.setIcon(new ImageIcon(new ImageIcon(iconPath).getImage().getScaledInstance((int)size.getWidth(),(int)size.getHeight(),Image.SCALE_AREA_AVERAGING)));
    }
}